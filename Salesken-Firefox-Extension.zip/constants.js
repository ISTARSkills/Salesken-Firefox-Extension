export default {
    "host": "https://api.talentify.in:8443",
    "socketurl": "ws://api.talentify.in:8443/cueSubscriber/userId"
}

